package melodyfinder.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Population {
        private List<Melody> _matingPool = new ArrayList<>();

        public List<Melody> melodies  = new ArrayList<>();

        public Integer bestFitness() {
            return melodies.stream()
                    .sorted(Comparator.comparing(Melody::getFitness).reversed())
                    .map(a -> a.fitness)
                    .findFirst().get();
        }

        public List<String> bestMelody() {
            return melodies.stream()
                    .sorted(Comparator.comparing(Melody::getFitness).reversed())
                    .map(a -> a.melodyNotes)
                    .findFirst().get();
        }

        public Population() {
            for (var i = 0; i < Constants.populationCount; i++)
            {
                melodies.add(new Melody());
            }
        }

        public void GenerateNewPopulation() {
            TournamentCrossOver();
            CalculateFitness();
        }

        public void CalculateFitness() {
            for(Melody melody : melodies){
                melody.CalculateFitness();
            }
        }


        private void TournamentCrossOver() {
            GenerateTurnamentMatingPool();

            Melody bestMelody = melodies.stream()
                    .max(Comparator.comparing(Melody::getFitness)).get();

            melodies.clear();

            if (Constants.saveBest) {
                melodies.add(bestMelody);
            }


            for (int i = 0; i < Constants.populationCount;) {
                Melody parentA = _matingPool.get(Constants.random.nextInt(_matingPool.size()));
                Melody parentB = _matingPool.get(Constants.random.nextInt(_matingPool.size()));

                if (Constants.random.nextInt(100) > Constants.crossoverRate) {
                    i++;

                    if (parentA.fitness > parentB.fitness) {
                        Melody melody = new Melody(parentA.melodyNotes);
                        melody.Mutatate();

                        melodies.add(melody);
                    } else {
                        Melody melody = new Melody(parentB.melodyNotes);
                        melody.Mutatate();

                        melodies.add(melody);
                    }

                    continue;
                }

                i += 2;

                if (Constants.crossoverType == CrossoverType.ONE_POINT) {
                    onePointCrossover(parentA, parentB);
                } else {
                    twoPointCrossover(parentA, parentB);
                }
            }
        }

        private void onePointCrossover(Melody parentA, Melody parentB) {
            var splitPoint = Constants.random.nextInt(Constants.getMelody().size());

            List<String> childA = new ArrayList<>();
            List<String> childB = new ArrayList<>();

//            childA.append(parentA.melodyNotes.substring(0, splitPoint));
//            childA.append(parentB.melodyNotes.substring(splitPoint));
            childA = Stream.concat(parentA.melodyNotes.subList(0, splitPoint).stream(),
                    parentB.melodyNotes.subList(splitPoint, parentB.melodyNotes.size()).stream())
                    .collect(Collectors.toList()) ;

            childB = Stream.concat(parentB.melodyNotes.subList(0, splitPoint).stream(),
                    parentA.melodyNotes.subList(splitPoint, parentA.melodyNotes.size()).stream())
                    .collect(Collectors.toList());
//            childB.append(parentB.melodyNotes.substring(0, splitPoint));
//            childB.append(parentA.melodyNotes.substring(splitPoint));

            Melody melodyA = new Melody(childA);
            melodyA.CalculateFitness();

            if (melodyA.fitness <= parentA.fitness || melodyA.fitness <= parentB.fitness) {
                melodyA.Mutatate();
            }

            Melody melodyB = new Melody(childB);
            melodyB.CalculateFitness();

            if (melodyB.fitness <= parentA.fitness || melodyB.fitness <= parentB.fitness) {
                melodyB.Mutatate();
            }

            melodies.add(melodyA);
            melodies.add(melodyB);
        }

        private void twoPointCrossover(Melody parentA, Melody parentB)
        {
            int splitPoint1 = Constants.random.nextInt(Constants.getMelody().size());
            int splitPoint2 = Constants.random.nextInt(splitPoint1, Constants.getMelody().size());

            List<String> childA = new ArrayList<>();
            List<String> childB = new ArrayList<>();

            childA = Stream.of(
                    parentA.melodyNotes.subList(0, splitPoint1),
                    parentB.melodyNotes.subList(splitPoint1, splitPoint2),
                    parentA.melodyNotes.subList(splitPoint2, parentA.melodyNotes.size())
                    ).flatMap(Collection::stream)
                    .collect(Collectors.toList());

//            childA.append(parentA.melodyNotes.substring(0,splitPoint1));
//            childA.append(parentB.melodyNotes.substring(splitPoint1, splitPoint2));
//            childA.append(parentA.melodyNotes.substring(splitPoint2));

            childB = Stream.of(
                            parentB.melodyNotes.subList(0, splitPoint1),
                            parentA.melodyNotes.subList(splitPoint1, splitPoint2),
                            parentB.melodyNotes.subList(splitPoint2, parentB.melodyNotes.size())
                    ).flatMap(Collection::stream)
                    .collect(Collectors.toList());

//            childB.append(parentB.melodyNotes.substring(0,splitPoint1));
//            childB.append(parentA.melodyNotes.substring(splitPoint1, splitPoint2));
//            childB.append(parentB.melodyNotes.substring(splitPoint2));

            Melody melodyA = new Melody(childA);
            melodyA.CalculateFitness();

            if (melodyA.fitness <= parentA.fitness || melodyA.fitness <= parentB.fitness) {
                melodyA.Mutatate();
            }

            Melody melodyB = new Melody(childB);
            melodyB.CalculateFitness();

            if (melodyB.fitness <= parentA.fitness || melodyB.fitness <= parentB.fitness) {
                melodyB.Mutatate();
            }

            melodies.add(melodyA);
            melodies.add(melodyB);
        }

        private void GenerateTurnamentMatingPool()
        {
            _matingPool.clear();

            var _matingPoolSize = (int)(Constants.populationCount * 0.2);

            for (var i = 0; i < _matingPoolSize; i++)
            {
                Melody bestMelody = melodies.get(Constants.random.nextInt(melodies.size()));

                for (var j = 0; j < Constants.numberOfItemsInTournament - 1; j++)
                {
                    Melody tmpMelody = melodies.get(Constants.random.nextInt(melodies.size()));

                    if (bestMelody.fitness < tmpMelody.fitness)
                    {
                        bestMelody = tmpMelody;
                    }
                }

                melodies.remove(bestMelody);
                _matingPool.add(bestMelody);
            }
        }
}
