package melodyfinder.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;

public class Melody {
    public List<String> melodyNotes = new ArrayList<>();

    public int fitness;

    public Melody()
    {
        for (int i = 0; i < Constants.getMelody().size(); i++)
        {
            int noteIndex = Constants.random.nextInt(Constants.availableNotes.size());
            melodyNotes.add(Constants.availableNotes.get(noteIndex));
        }
    }

    public Melody(List<String> melody)
    {
        melodyNotes = new ArrayList<>(melody);
    }

    public Melody(List<String> melodyA, List<String> melodyB)
    {
        melodyNotes = Stream.concat(melodyA.stream(), melodyB.stream()).toList();
    }

    public int getFitness() {
        return fitness;
    }

    public void CalculateFitness()
    {
        fitness = 0;

        for (var i = 0; i < Constants.getMelody().size(); i++)
        {
            fitness += Objects.equals(melodyNotes.get(i), Constants.getMelody().get(i)) ? 1 : 0;
        }
    }

    public void Mutatate()
    {
        //StringBuilder mutatedNotes = new StringBuilder(melodyNotes);
        List<String> mutatedNotes = melodyNotes;

        for (var i = 0; i < Constants.getMelody().size(); i++)
        {
            if (Constants.random.nextInt(100) < Constants.mutationRate)
            {
                var noteIndex = Constants.random.nextInt(0, Constants.availableNotes.size());
                String mutatedNote = Constants.availableNotes.get(noteIndex);
                mutatedNotes.set(i, mutatedNote);
            }
        }

        melodyNotes = new ArrayList<>(mutatedNotes);
    }
}
