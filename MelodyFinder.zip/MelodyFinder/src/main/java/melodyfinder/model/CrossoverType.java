package melodyfinder.model;

public enum CrossoverType {
    ONE_POINT(1),
    TWO_POINT(2);

    CrossoverType(int i) {
    }
}
