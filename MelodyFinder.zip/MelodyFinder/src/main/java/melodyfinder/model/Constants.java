package melodyfinder.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Constants {
    public static Random random = new Random();

    public static List<String> availableNotes = new ArrayList<>();

    public static List<String> availableTones = List.of("C", "C#", "Db", "D", "D#", "Eb", "E", "F", "F#", "Gb", "G",
            "G#", "Ab", "A", "A#", "Bb", "B");

    public static List<Character> availableDurations = List.of('w', 'h', 'q', 'e', 's');

    public static List<Character> availableOctaves = List.of('1', '2', '3', '4', '5', '6');

    private static List<String> melody;

    public static int populationCount;

    public static int numberOfItemsInTournament;

    public static int crossoverRate;

    public static int mutationRate;

    public static int maxMutation;

    public static int mutationIncrement;

    public static CrossoverType crossoverType;

    public static boolean saveBest;

    public static List<String> getMelody() {
        return melody;
    }

    public static void setMelody(List<String> melody) {
        Constants.melody = melody;
    }

    public static final Integer NUMBER_OF_ITERATIONS = 5;

    public static List<Long> listOfDurations = new ArrayList<>();

    public static List<Integer> listOfGenCount = new ArrayList<>();
}
