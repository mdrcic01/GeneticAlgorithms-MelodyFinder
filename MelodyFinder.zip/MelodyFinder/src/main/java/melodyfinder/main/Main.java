package melodyfinder.main;

import melodyfinder.model.Constants;
import melodyfinder.model.CrossoverType;
import melodyfinder.model.Population;
import org.jfugue.pattern.Pattern;
import org.jfugue.player.Player;

import java.time.Duration;
import java.time.Instant;
import java.util.*;

import static melodyfinder.model.Constants.NUMBER_OF_ITERATIONS;

public class Main {
    public static void main(String[] args) {
        /*
        1. Twinkle twinkle little star
        2. Axel F
        3. Happy birthday
        4. Love me tender
        5. Pirates of the Caribbian
        */
        pickMelody(1);
        Constants.populationCount = 5000;
        Constants.crossoverRate = 80;
        Constants.mutationRate = 5;
        Constants.numberOfItemsInTournament = (int)(Constants.populationCount * 0.8);
        Constants.crossoverType = CrossoverType.TWO_POINT;
        Constants.saveBest = true;

        generateNotes();

        Scanner userInput = new Scanner(System.in);
        for(int i = 0; i<NUMBER_OF_ITERATIONS; i++){
            programIteration(userInput, i+1);
        }

        OptionalDouble avgDuration = Constants.listOfDurations.stream().mapToDouble(Long::longValue).average();
        OptionalDouble avgGenCount = Constants.listOfGenCount.stream().mapToDouble(Integer::longValue).average();

        System.out.println("................OVERALL RESULT.......................");
        System.out.println("Average duration: " + avgDuration.getAsDouble());
        System.out.println("Average generation count: " + avgGenCount.getAsDouble());
        System.out.println("....................END..............................");

    }

    public static void programIteration(Scanner userInput, Integer iteration){
        System.out.println("Iteration initiated...");
        Instant startTime = Instant.now();

        Population population = new Population();
        population.CalculateFitness();
        var index = 0;

        Player player = new Player();
        while (!Objects.equals(population.bestMelody(), Constants.getMelody())) {
            index++;
            population.GenerateNewPopulation();

            String bestMelody = String.join(" ", population.bestMelody());

            System.out.println(bestMelody);

            Pattern pattern = new Pattern(bestMelody).setTempo(120).setInstrument("Guitar");


            player.play(pattern);

//            if(index%100 == 0) {
//                player.play(pattern);
//            }
        }

        Instant endTime = Instant.now();

        Duration time = Duration.between(startTime, endTime);

        Pattern pattern1 = new Pattern(String.join(" ", Constants.getMelody()))
                .setTempo(120).setInstrument("Guitar");

        System.out.println("-----------------------------------------------------------------------");
        System.out.println("Iteracija: " + iteration);
        System.out.println("Rjesenje: " + population.bestMelody());
        System.out.println();
        System.out.println("Broj generacija: " + index);
        System.out.println("Utroseno vrijeme: " + time.toMillis());
        System.out.println("-----------------------------------------------------------------------");

        player.play(pattern1);

        System.out.println("press ENTER to continue...");
        userInput.nextLine();


        Constants.listOfGenCount.add(index);
        Constants.listOfDurations.add(time.toMillis());
    }

    public static void generateNotes(){
        String tmpNote = "";
        String tmpTone;
        String tmpDuration;
        String tmpOctave;
        for(String tone : Constants.availableTones){
            tmpTone = tone;
            for(Character octave : Constants.availableOctaves){
                tmpOctave = octave.toString();
                for(Character duration : Constants.availableDurations){
                    tmpDuration = duration.toString();
                    tmpNote = tmpTone + tmpOctave + tmpDuration;
                    Constants.availableNotes.add(tmpNote);
                }
            }
        }
    }

    private static void setMelody(String melody){
        Constants.setMelody(Arrays.stream(melody.split(",")).toList());
    }

    private static void pickMelody(Integer pick){
        if(pick == 1) setMelody("C4q,C4q,G4q,G4q,A4q,A4q,G4h,F4q,F4q,E4q,E4q,D4q,D4q,C4h");
        if(pick == 2) setMelody("F#4e,A4q,F#4q,F#4s,B4e,F#4e,E4e,F#4e,C#5q,F#4e,F#4s,D5e,C#5e,A4e,F#4e,C#5e,F#5e,F#4s,E4e,E4s,C#4e,G#4e,F#4w");
        if(pick == 3) setMelody("C4e,C4e,D4q,C4q,F4q,E4h,C4e,C4e,D4q,C4q,G4q,F4h,C4e,C4e,C5q,A4q,F4q,E4q,D4h,Bb4e,Bb4e,A4q,F4q,G4q,F4h");
        if(pick == 4) setMelody("C4q,F4q,E4q,F4q,G4q,D4q,G4h,F4q,E4q,D4q,E4q,F4w,A4q,A4q,A4q,A4q,A4q,A4q,A4h,A4q,G4q,F4q,G4q,A4w,A4q,A4q,Bb4q,A4q,G4q,D4q,G4h,F4q,E4q,A4q,G4q,F4w");
        if(pick == 5) setMelody("A3e,C4e,D4q,D4q,D4e,E4e,F4q,F4q,F4e,G4e,E4q,E4q,D4e,C4e,C4e,D4e,A3e,C4e,D4q,D4q,D4e,E4e,F4q,F4q,F4e,G4e,E4q,E4q,D4e,C4e,D4h,A3e,C4e,D4q,D4q,D4e,F4e,G4q,G4q,G4e,A4e,B4q,B4q,A4e,G4e,A4e,D4e,D4e,E4e,F4q,F4q,G4q,A4e,D4e,D4e,F4e,E4q,E4q,F4e,D4e,E4h,A4e,C5e,D5q,D5q,D5e,E5e,F5q,F5q,F5e,G5e,E5q,E5q,D5e,C5e,C5e,D5e");
    }
}
